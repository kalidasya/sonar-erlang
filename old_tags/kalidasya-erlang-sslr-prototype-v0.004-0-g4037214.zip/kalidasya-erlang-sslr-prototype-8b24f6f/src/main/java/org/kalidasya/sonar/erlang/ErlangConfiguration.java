package org.kalidasya.sonar.erlang;

import java.nio.charset.Charset;

import org.sonar.squid.api.SquidConfiguration;

public class ErlangConfiguration extends SquidConfiguration{
	
	public ErlangConfiguration(Charset charset){
		super(charset);
	}
	
}
